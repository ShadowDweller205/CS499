/**Mark A.Ellis
 *CS499 Final Project
 * @author Lost
 */
import java.sql.*;
import java.util.Scanner;


public class zooLogic {
/* This part opens the database file from the texts folder,
*reads the file and closes the file
*/
    public void animals(){
 
        Scanner scnr = new Scanner(System.in);
//Using SQL SELECT Query
try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver

              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://texts/Zoo.accdb");//Establishing Connection

              System.out.println("Connected Successfully");

 
//Using SQL SELECT Query

              PreparedStatement preparedStatement=connection.prepareStatement("select * from Animals");

//Creaing Java ResultSet object

              ResultSet resultSet=preparedStatement.executeQuery();

              while(resultSet.next()){

                   String Type=resultSet.getString("Type");

                   String AnimalName=resultSet.getString("AnimalName");
                   
                   String Age=resultSet.getString("Age");
                   
                   String HealthConcerns=resultSet.getString("Health concerns");
                   
                   String FeedingSchedule=resultSet.getString("Feeding Schedule");

//Printing Results
                   System.out.println((Type)+" "+(AnimalName)+" "+(Age)+" "+(HealthConcerns)+" "+(FeedingSchedule));

              }
 
         }catch(ClassNotFoundException | SQLException e){

              System.out.println("Error in connection");
          }
    }
    
    
 /* This part opens the database file from the texts folder,
*reads the file and closes the file
*/   
    public void habitats(){
        Scanner scnr = new Scanner(System.in);
try
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver

              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://texts/Zoo.accdb");//Establishing Connection

              System.out.println("Connected Successfully");

//Using SQL SELECT Query

              PreparedStatement preparedStatement=connection.prepareStatement("select * from Habitat");

//Creaing Java ResultSet object

              ResultSet resultSet=preparedStatement.executeQuery();

              while(resultSet.next()){

                   String Type=resultSet.getString("Type");

                   String Temp=resultSet.getString("Temp");
                   
                   String FoodSource=resultSet.getString("FoodSource");
                   
                   String Cleanliness=resultSet.getString("Cleanliness");

//Printing Results

                   System.out.println((Type)+" "+(Temp)+" "+(FoodSource)+" "+(Cleanliness));

              }
              
          }catch(ClassNotFoundException | SQLException e){

              System.out.println("Error in connection");

          }

    }
     

/* This part opens the database file from the texts folder,
*reads the file and closes the file
*/
    public void staffing(){
        Scanner scnr = new Scanner(System.in);
try
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver

              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://texts/Zoo.accdb");//Establishing Connection

              System.out.println("Connected Successfully");

//Using SQL SELECT Query

              PreparedStatement preparedStatement=connection.prepareStatement("select * from Animals");

//Creaing Java ResultSet object

              ResultSet resultSet=preparedStatement.executeQuery();

              while(resultSet.next()){

                   String FirstName=resultSet.getString("First Name");

                   String LastName=resultSet.getString("Last Name");
                   
                   String Age=resultSet.getString("Age");
                   
                   String Habitat=resultSet.getString("Habitat");
                   
                   String HealthConcerns=resultSet.getString("Health concerns");

//Printing Results

                   System.out.println((FirstName)+" "+(LastName)+" "+(Age)+" "+(Habitat)+" "+(HealthConcerns));

              }
              
          }catch(ClassNotFoundException | SQLException e){

              System.out.println("Error in connection");

          }

    }
}