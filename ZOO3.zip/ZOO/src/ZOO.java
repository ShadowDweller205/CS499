/**Mark A.Ellis
 *IT 145 Final Project 
 * @author Lost
 */
import java.util.Scanner;
public class ZOO {

    
    public static void main(String[] args) {
    Scanner scnr = new Scanner(System.in);
// variables used in the main program
        int exit = 0; 
        int choice = 3;
        String userChoice = " ";
//  Asks a user if they want to monitor an animal, monitor a habitat, or exit  
    while (exit <= 0) { //Allows a user to return to the original options
     System.out.println("Enter animals, habitats, staffing, or exit");
     userChoice = scnr.nextLine();
     System.out.println("You have chosen " + userChoice);   
     if (userChoice.equals("animals")) {
         (choice) = 0;
     } 
     else if (userChoice.equals("habitats")) {
         (choice) = 1;
     }
     else if (userChoice.equals("staffing")) {
         (choice) = 2;
     }
    else if (userChoice.equals("exit")) {
         (choice) = 3;
     }
     
     
     switch (choice){
          case 0:
              zooLogic animals = new zooLogic();
              animals.animals();
              break;
         case 1:
              zooLogic habitats = new zooLogic();
              habitats.habitats();
              break;
         case 2:
              zooLogic staffing = new zooLogic();
              staffing.staffing();
              break;
         case 3:
              exit = (exit) + 1;
              break;    
         default:
             
             break;
      }  
    }
    return;
    }
}      
          
    
