/**Mark A.Ellis
 *IT 145 Final Project
 * @author Lost
 */
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

public class zooLogic {
    
    public void animals(){
        Scanner scnr = new Scanner(System.in);
// variables used in the animals program       
        BufferedReader readerAnimal;
        
        int i = 0;
        int blankLine = 0;
        int seperateSection = 0;
        int index = -1;
        String[] details = null;
        String line = null;   
// Displays a list of animal/habitat options (based on the previous selection)       
        File file = new File ("texts/animals.txt");
        
    try {
        readerAnimal = new BufferedReader(new FileReader(file));
        System.out.println("What animal would you like to see?");
            while((line=readerAnimal.readLine())!= null) {
            seperateSection=0;
                if(line.equals("")) {
                blankLine++;
                   if(blankLine == 1) {
                   details = new String[i];
                   }
                seperateSection = 1;
                index++;
                }
                if(blankLine == 0) {  
                i++;
                System.out.print("Press " + i + " for");
                System.out.println(" " + line);
                }
                else if(blankLine != 0 && seperateSection == 0) {       
                details[index] = details[index] + "\n" + line;
                }
            }
        readerAnimal.close();
        int choose=scnr.nextInt();
          
        System.out.println(details[choose -1]);
//Uses a dialog box to alert the zookeeper if the monitor detects something out of the normal range
        if (details[choose -1].contains("*****")) {
               JOptionPane.showMessageDialog(null, (details[choose -1]));   
            }
    }          
    catch(IOException ioe){
    }      
}  

    public void habitats(){
        Scanner scnr = new Scanner(System.in);
// variables used in the habitats program
        BufferedReader habitatAnimal;
        
        int i = 0;
        int blankLine = 0;
        int seperateSection = 0;
        int index = -1;
        String[] details = null;
        String line = null;
// Displays a list of animal/habitat options (based on the previous selection)
        File file = new File ("texts/habitats.txt");
        
    try {
        habitatAnimal = new BufferedReader(new FileReader(file));
        System.out.println("What habitat would you like to see?");
        while((line=habitatAnimal.readLine())!= null) {
            seperateSection=0;
            if(line.equals("")) {
                blankLine++;
                   if(blankLine == 1) {
                    details = new String[i];
                   }
                seperateSection = 1;
                index++;
            }
            if(blankLine == 0) {  
                i++;
                System.out.print("Press " + i + " for");
                System.out.println(" " + line);
            }
            else if(blankLine != 0 && seperateSection == 0) {       
                details[index] = details[index] + "\n" + line;
            }
        }
        habitatAnimal.close();
        int choose=scnr.nextInt();
        System.out.println(details[choose-1]);
//Uses a dialog box to alert the zookeeper if the monitor detects something out of the normal range
        if (details[choose -1].contains("*****")) {
               JOptionPane.showMessageDialog(null, (details[choose -1]) );   
            }
    }
     
    catch(IOException ioe){
    }      
    } 
    
    public void staffing(){
        Scanner scnr = new Scanner(System.in);
// variables used in the staffing program
        BufferedReader staff;
        
        int i = 0;
        int blankLine = 0;
        int seperateSection = 0;
        int index = -1;
        String[] details = null;
        String line = null;
// Displays a list of staff options (based on the previous selection)
        File file = new File ("texts/staff.txt");
        
    try {
        staff = new BufferedReader(new FileReader(file));
        System.out.println("What staff member would you like to see?");
        while((line=staff.readLine())!= null) {
            seperateSection=0;
            if(line.equals("")) {
                blankLine++;
                   if(blankLine == 1) {
                    details = new String[i];
                   }
                seperateSection = 1;
                index++;
            }
            if(blankLine == 0) {  
                i++;
                System.out.print("Press " + i + " for");
                System.out.println(" " + line);
            }
            else if(blankLine != 0 && seperateSection == 0) {       
                details[index] = details[index] + "\n" + line;
            }
        }
        staff.close();
        int choose=scnr.nextInt();
        System.out.println(details[choose-1]);
//Uses a dialog box to alert the zookeeper if the monitor detects something out of the normal range
        if (details[choose -1].contains("*****")) {
               JOptionPane.showMessageDialog(null, (details[choose -1]) );   
            }
    }

    catch(IOException ioe){
    }      
    }   
    
}

    





        
    
    
    
    
    
    
    
    
    

